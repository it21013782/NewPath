import React from "react"
import AllBusinesses from "../GetAll/AllBusinesses"

export default function HomePage() {
  return (
    <div>
      <AllBusinesses />
    </div>
  )
}


/*const mongoose = require('mongoose');

const ideaSchema = new mongoose.Schema({
  fullName: {
    type: String,
    required: true,
  },
  age: {
    type: Number,
    required: true,
  },
  category: {
    type: String,
    required: true,
  },
  currentStage: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
 
  telephoneNumber: {
    type: String,
    required: true,
  },
  businessProposal: {
    type: String,
    required: true,
  },
  targetAudience: {
    type: String,
    required: true,
  },

  image: {
    type: String,
    required: true,
  },
});

const Idea = mongoose.model('Idea', ideaSchema);

module.exports = Idea;*/

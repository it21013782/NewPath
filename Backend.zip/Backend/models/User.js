const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },

  fullName: {
    type: String,
    required: true,
  },

  category: {
    type: String,
    required: true,

  },
 
  phoneNumber: {
    type: Number,
    required: true,
  }
});

const User = mongoose.model('User', userSchema);

module.exports = User;